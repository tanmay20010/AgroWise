// This file reads your Firebase configuration from environment variables.
// You must create a .env file in the root of your project and add your
// Firebase project configuration there.

// To find your Firebase config object:
// 1. Go to the Firebase console for your project.
// 2. In the Project settings, go to the "Your apps" card.
// 3. In your app's settings, find the "Firebase SDK snippet" section and select the "Config" option.
// 4. Copy the values into your .env file.

export const firebaseConfig = {
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
  storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID,
  measurementId: process.env.NEXT_PUBLIC_FIREBASE_MEASUREMENT_ID
};
