export type SecurityRuleContext = {
  path: string;
  operation: 'get' | 'list' | 'create' | 'update' | 'delete';
  requestResourceData?: any;
};

export class FirestorePermissionError extends Error {
  __proto__ = Error;
  private readonly _context: SecurityRuleContext;
  private readonly _timestamp: number;

  constructor(context: SecurityRuleContext) {
    const message =
      'FirestoreError: Missing or insufficient permissions: The following request was denied by Firestore Security Rules:';
    super(message);
    this._context = context;
    this._timestamp = Date.now();
    Object.setPrototypeOf(this, FirestorePermissionError.prototype);
  }

  get context() {
    return this._context;
  }

  get timestamp() {
    return this._timestamp;
  }
}
