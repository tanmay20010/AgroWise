'use client';
import { ReactNode, useMemo } from 'react';
import { initializeFirebase } from '.';
import { FirebaseProvider, FirebaseContextValue } from './provider';
import { firebaseConfig } from './config';
import { AlertCircle } from 'lucide-react';

export function FirebaseClientProvider({ children }: { children: ReactNode }) {
  if (!firebaseConfig.apiKey) {
    return (
      <div className="flex h-screen w-full items-center justify-center bg-background p-4">
          <div className="max-w-md rounded-lg border border-destructive/50 bg-card p-8 text-center shadow-lg">
              <AlertCircle className="mx-auto h-12 w-12 text-destructive" />
              <h1 className="mt-4 text-2xl font-bold text-destructive">Firebase Not Configured</h1>
              <p className="mt-4 text-muted-foreground">
                  Your Firebase API keys are missing. Please add your configuration to 
                  the <code className="mx-1 rounded bg-muted px-1.5 py-1 font-mono text-sm shadow-sm">.env</code> file
                  to enable authentication and database features.
              </p>
              <p className="mt-4 text-xs text-muted-foreground">
                  You can find your keys in your project settings on the Firebase Console. After adding them, you need to restart the server.
              </p>
          </div>
      </div>
    );
  }

  const value: FirebaseContextValue = useMemo(() => initializeFirebase(), []);
  return <FirebaseProvider value={value}>{children}</FirebaseProvider>;
}
