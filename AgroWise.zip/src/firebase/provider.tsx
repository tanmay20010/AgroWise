'use client';
import {
  createContext,
  useContext,
  ReactNode,
  useMemo,
  Context,
} from 'react';
import type { FirebaseApp } from 'firebase/app';
import type { Auth } from 'firebase/auth';
import type { Firestore } from 'firebase/firestore';

import { FirebaseErrorListener } from '@/components/FirebaseErrorListener';

export interface FirebaseContextValue {
  app: FirebaseApp | null;
  auth: Auth | null;
  firestore: Firestore | null;
}

export const FirebaseContext = createContext<FirebaseContextValue | null>(null);

export interface FirebaseProviderProps {
  children: ReactNode;
  value: FirebaseContextValue;
}

export function FirebaseProvider({ children, value }: FirebaseProviderProps) {
  const memoizedValue = useMemo(() => value, [value]);

  return (
    <FirebaseContext.Provider value={memoizedValue}>
      <FirebaseErrorListener />
      {children}
    </FirebaseContext.Provider>
  );
}

function useFirebaseContext<T>(
  context: Context<T | null>,
  hookName: string,
  providerName: string
) {
  const contextValue = useContext(context);
  if (contextValue === null) {
    throw new Error(`\`${hookName}\` must be used within a \`${providerName}\``);
  }
  return contextValue;
}

export function useFirebase() {
  return useFirebaseContext(
    FirebaseContext,
    'useFirebase',
    'FirebaseProvider'
  );
}

export const useFirebaseApp = () => useFirebase().app!;
export const useAuth = () => useFirebase().auth!;
export const useFirestore = () => useFirebase().firestore!;
