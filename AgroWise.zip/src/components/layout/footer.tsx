import { Logo } from '@/components/logo';
import { Github, Twitter, Linkedin } from 'lucide-react';
import Link from 'next/link';

const footerNav = [
    { name: 'How it Works', href: '/#how-it-works' },
    { name: 'Features', href: '/#features' },
    { name: 'Get Advice', href: '/advice' },
];

const socialLinks = [
    { name: 'Twitter', icon: Twitter, href: '#' },
    { name: 'Github', icon: Github, href: '#' },
    { name: 'LinkedIn', icon: Linkedin, href: '#' },
]

export function AppFooter() {
    return (
        <footer className="bg-card border-t">
            <div className="container mx-auto px-6 py-12">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    <div className="flex flex-col items-start">
                        <Logo />
                        <p className="mt-4 text-sm text-muted-foreground">
                            A technology-driven solution for smarter farming.
                        </p>
                    </div>
                    <div className="md:col-span-2 grid grid-cols-2 sm:grid-cols-3 gap-8">
                        <div>
                            <h3 className="font-headline text-sm font-semibold tracking-wider uppercase">Navigation</h3>
                            <ul className="mt-4 space-y-2">
                                {footerNav.map(item => (
                                    <li key={item.name}>
                                        <Link href={item.href} className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                                            {item.name}
                                        </Link>
                                    </li>
                                ))}
                            </ul>
                        </div>
                        <div>
                             <h3 className="font-headline text-sm font-semibold tracking-wider uppercase">Legal</h3>
                             <ul className="mt-4 space-y-2">
                                 <li><Link href="/" className="text-sm text-muted-foreground hover:text-foreground transition-colors">Privacy Policy</Link></li>
                                 <li><Link href="/" className="text-sm text-muted-foreground hover:text-foreground transition-colors">Terms of Service</Link></li>
                             </ul>
                        </div>
                        <div>
                             <h3 className="font-headline text-sm font-semibold tracking-wider uppercase">Contact</h3>
                             <ul className="mt-4 space-y-2">
                                 <li><a href="mailto:support@agrowise.com" className="text-sm text-muted-foreground hover:text-foreground transition-colors">support@agrowise.com</a></li>
                                 <li><a href="tel:+1234567890" className="text-sm text-muted-foreground hover:text-foreground transition-colors">+1 (234) 567-890</a></li>
                             </ul>
                        </div>
                    </div>
                </div>
                <div className="mt-12 pt-8 border-t flex flex-col sm:flex-row justify-between items-center">
                    <p className="text-sm text-muted-foreground">&copy; {new Date().getFullYear()} AgroWise. All rights reserved.</p>
                    <div className="flex items-center space-x-4 mt-4 sm:mt-0">
                        {socialLinks.map(social => (
                            <a key={social.name} href={social.href} className="text-muted-foreground hover:text-foreground transition-colors">
                                <social.icon className="w-5 h-5" />
                                <span className="sr-only">{social.name}</span>
                            </a>
                        ))}
                    </div>
                </div>
            </div>
        </footer>
    );
}
