import Image from 'next/image';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { PlaceHolderImages } from '@/lib/placeholder-images';
import { MapPin, Sprout, Calculator, ClipboardList } from 'lucide-react';

const howItWorksSteps = [
  {
    step: 1,
    title: 'Input Your Details',
    description: 'Provide your farm\'s location and land size.',
    icon: <MapPin className="h-10 w-10 text-primary" />,
  },
  {
    step: 2,
    title: 'Get Recommendations',
    description: 'Our AI analyzes your data to suggest the best crops.',
    icon: <Sprout className="h-10 w-10 text-primary" />,
  },
  {
    step: 3,
    title: 'Estimate Costs',
    description: 'Receive a detailed breakdown of potential expenses.',
    icon: <Calculator className="h-10 w-10 text-primary" />,
  },
  {
    step: 4,
    title: 'Follow Guidance',
    description: 'Get step-by-step crop care instructions.',
    icon: <ClipboardList className="h-10 w-10 text-primary" />,
  },
];

const features = [
  {
    title: 'AI Crop Recommendation',
    description: 'Leverage AI to get crop suggestions perfectly matched to your farm\'s conditions.',
    image: PlaceHolderImages.find(img => img.id === 'feature-recommendation'),
  },
  {
    title: 'Detailed Crop Care',
    description: 'Follow easy, step-by-step guides for optimal growth from planting to harvest.',
    image: PlaceHolderImages.find(img => img.id === 'feature-care'),
  },
  {
    title: 'Cost & Profit Estimation',
    description: 'Plan your budget with accurate cost estimates and potential revenue projections.',
    image: PlaceHolderImages.find(img => img.id === 'feature-cost'),
  },
];


export default function Home() {
  const heroImage = PlaceHolderImages.find(img => img.id === 'hero-farm');

  return (
    <div className="flex flex-col items-center">
      {/* Hero Section */}
      <section className="relative h-[60vh] w-full text-white">
        {heroImage && (
          <Image
            src={heroImage.imageUrl}
            alt={heroImage.description}
            fill
            className="object-cover"
            priority
            data-ai-hint={heroImage.imageHint}
          />
        )}
        <div className="absolute inset-0 bg-black/50" />
        <div className="relative z-10 flex h-full flex-col items-center justify-center text-center p-4">
          <h1 className="font-headline text-4xl md:text-6xl font-bold leading-tight animate-fade-in-up">
            Smart Crop Advisory System
          </h1>
          <p className="mt-4 max-w-2xl text-lg md:text-xl animate-fade-in-up animation-delay-300">
            A technology-driven solution for smarter, more profitable farming.
          </p>
          <Button asChild size="lg" className="mt-8 animate-fade-in-up animation-delay-600 bg-primary hover:bg-primary/90 text-primary-foreground">
            <Link href="/signup">Get Started</Link>
          </Button>
        </div>
      </section>

      {/* How It Works Section */}
      <section id="how-it-works" className="w-full py-16 md:py-24 bg-card">
        <div className="container mx-auto px-4">
          <h2 className="font-headline text-3xl md:text-4xl font-bold text-center">How It Works</h2>
          <p className="text-center text-muted-foreground mt-2 mb-12">A simple 4-step process to boost your farm's productivity.</p>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {howItWorksSteps.map((step, index) => (
              <div key={step.step} className="text-center p-6 rounded-lg transition-transform hover:-translate-y-2 animate-fade-in-up" style={{ animationDelay: `${index * 200}ms` }}>
                <div className="flex items-center justify-center h-20 w-20 mx-auto bg-primary/10 rounded-full mb-4">
                  {step.icon}
                </div>
                <h3 className="font-headline text-xl font-bold mb-2">{step.title}</h3>
                <p className="text-muted-foreground">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="w-full py-16 md:py-24">
        <div className="container mx-auto px-4">
          <h2 className="font-headline text-3xl md:text-4xl font-bold text-center">Key Features</h2>
          <p className="text-center text-muted-foreground mt-2 mb-12">Everything you need for successful farming, all in one place.</p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <Card key={feature.title} className="overflow-hidden transition-shadow hover:shadow-xl animate-fade-in-up" style={{ animationDelay: `${index * 200}ms` }}>
                {feature.image && (
                   <div className="w-full h-48 relative">
                     <Image
                        src={feature.image.imageUrl}
                        alt={feature.image.description}
                        fill
                        className="object-cover"
                        data-ai-hint={feature.image.imageHint}
                      />
                   </div>
                )}
                <CardHeader>
                  <CardTitle className="font-headline">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
