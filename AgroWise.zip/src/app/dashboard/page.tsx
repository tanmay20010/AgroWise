'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useUser } from '@/firebase';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';

export default function DashboardPage() {
  const { user, loading } = useUser();
  const router = useRouter();

  useEffect(() => {
    if (!loading && !user) {
      router.push('/login');
    }
  }, [user, loading, router]);

  if (loading || !user) {
    return (
        <div className="container py-12 md:py-24">
            <div className="max-w-4xl mx-auto">
                 <Card>
                    <CardHeader>
                        <Skeleton className="h-8 w-1/2" />
                        <Skeleton className="h-4 w-3/4" />
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <Skeleton className="h-10 w-1/3" />
                        <Skeleton className="h-20 w-full" />
                    </CardContent>
                </Card>
            </div>
        </div>
    );
  }

  return (
    <div className="container py-12 md:py-24">
      <div className="max-w-4xl mx-auto">
        <Card>
          <CardHeader>
            <CardTitle className="font-headline text-3xl">Welcome, {user.displayName || 'Farmer'}!</CardTitle>
            <CardDescription>This is your personalized dashboard. Here's a summary of your farm.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <h3 className="font-semibold text-lg mb-2">Ready to get started?</h3>
              <p className="text-muted-foreground mb-4">Get personalized crop recommendations for your land.</p>
              <Button onClick={() => router.push('/advice')}>Get Advice Now</Button>
            </div>
             <div className="border-t pt-6">
                <h3 className="font-semibold text-lg mb-2">Account Details</h3>
                <p><strong>Email:</strong> {user.email}</p>
                <p><strong>UID:</strong> {user.uid}</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
