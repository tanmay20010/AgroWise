'use server';

import { suggestOptimalCrops, OptimalCropsInput } from '@/ai/flows/optimal-crop-suggestions';
import { getCropCareGuidance, CropCareGuidanceInput, CropCareGuidanceOutput } from '@/ai/flows/crop-care-guidance';
import { getCostEstimation, CostEstimationInput, CostEstimationOutput } from '@/ai/flows/cost-estimation';

export type RecommendationResult = {
    suggestedCrops: {
        cropName: string;
        suitabilityScore: number;
        highlights: string[];
    }[];
} | { error: string };


export async function getRecommendations(input: OptimalCropsInput): Promise<RecommendationResult> {
    if (!process.env.GEMINI_API_KEY) {
        return { error: 'The `GEMINI_API_KEY` environment variable is missing. Please add it to your .env file. You can get a key from Google AI Studio.' };
    }
    
    console.log("Getting recommendations for:", input);
    try {
        const result = await suggestOptimalCrops(input);
        if (!result || !result.suggestedCrops) {
            console.error("AI did not return expected output format for recommendations.");
            return { error: "Could not get recommendations. The AI returned an unexpected format." };
        }
        return result;
    } catch (error) {
        console.error("Error getting recommendations:", error);
        if (error instanceof Error) {
            if (error.message.includes('API key')) {
                return { error: 'The AI service is not configured correctly. Your API key may be invalid or have insufficient permissions.' };
            }
            return { error: `An error occurred while fetching recommendations: ${error.message}` };
        }
        return { error: "An unexpected error occurred while fetching recommendations. Please try again later." };
    }
}


export async function getCropCareAction(input: CropCareGuidanceInput): Promise<CropCareGuidanceOutput | { error: string }> {
    if (!process.env.GEMINI_API_KEY) {
        return { error: 'The `GEMINI_API_KEY` environment variable is missing.' };
    }
    try {
        const result = await getCropCareGuidance(input);
         if (!result || !result.guidance) {
            console.error("AI did not return expected output format for crop care.");
            return { error: "Could not get crop care guidance. The AI returned an unexpected format." };
        }
        return result;
    } catch (error) {
        console.error("Error getting crop care guidance:", error);
        return { error: "An unexpected error occurred while fetching crop care guidance." };
    }
}

export async function getCostEstimationAction(input: CostEstimationInput): Promise<CostEstimationOutput | { error: string }> {
    if (!process.env.GEMINI_API_KEY) {
        return { error: 'The `GEMINI_API_KEY` environment variable is missing.' };
    }
    try {
        const result = await getCostEstimation(input);
        if (!result || !result.costBreakdown) {
            console.error("AI did not return expected output format for cost estimation.");
            return { error: "Could not get cost estimation. The AI returned an unexpected format." };
        }
        return result;
    } catch (error) {
        console.error("Error getting cost estimation:", error);
        return { error: "An unexpected error occurred while fetching cost estimation." };
    }
}
