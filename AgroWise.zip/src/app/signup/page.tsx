import { AuthForm } from "@/components/auth/auth-form";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";

export default function SignupPage() {
  return (
    <div className="container py-12 md:py-24 flex items-center justify-center">
      <Card className="w-full max-w-md shadow-lg">
        <CardHeader className="text-center">
          <CardTitle className="font-headline text-3xl">Create an Account</CardTitle>
          <CardDescription>Join AgroWise and start farming smarter</CardDescription>
        </CardHeader>
        <CardContent>
          <AuthForm variant="signup" />
        </CardContent>
      </Card>
    </div>
  );
}
