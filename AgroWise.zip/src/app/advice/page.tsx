import { AdviceForm } from './advice-form';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';

export default function AdvicePage() {
  return (
    <div className="container py-12 md:py-24">
      <div className="max-w-2xl mx-auto">
        <Card className="shadow-lg">
          <CardHeader className="text-center">
            <CardTitle className="font-headline text-3xl">Get Personalized Crop Advice</CardTitle>
            <CardDescription>Tell us about your farm to receive AI-powered recommendations.</CardDescription>
          </CardHeader>
          <CardContent>
            <AdviceForm />
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
