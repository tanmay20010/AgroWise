import { Suspense } from 'react';
import { ResultsClient } from './results-client';
import Loading from './loading';

export default function ResultsPage() {
  return (
    <Suspense fallback={<Loading />}>
      <ResultsClient />
    </Suspense>
  );
}
