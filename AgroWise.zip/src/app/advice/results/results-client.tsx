'use client';

import { useEffect, useState } from 'react';
import { useSearchParams } from 'next/navigation';
import Image from 'next/image';
import Link from 'next/link';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { format } from "date-fns";
import { collection, addDoc, query, onSnapshot, orderBy, Timestamp } from 'firebase/firestore';

import { getRecommendations, getCropCareAction, getCostEstimationAction, RecommendationResult } from '@/app/actions';
import type { CropCareGuidanceOutput } from '@/ai/flows/crop-care-guidance';
import type { CostEstimationOutput } from '@/ai/flows/cost-estimation';
import { useUser, useFirestore } from '@/firebase';

import Loading from './loading';
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { CheckCircle, AlertTriangle, Droplets, Thermometer, DollarSign, Tractor, Shield, Sprout, Calendar, Wrench, MapPin, Scale, PlusCircle } from 'lucide-react';
import { PlaceHolderImages } from '@/lib/placeholder-images';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { Skeleton } from '@/components/ui/skeleton';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar as CalendarIcon } from 'lucide-react';
import { Calendar as CalendarComponent } from '@/components/ui/calendar';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

// Helper function to get the current season
const getSeason = () => {
  const month = new Date().getMonth(); // 0-11
  if (month >= 5 && month <= 9) return 'Kharif'; // June - October
  if (month >= 10 || month <= 2) return 'Rabi'; // November - March
  return 'Zaid'; // April - May
};

const getCropImage = (cropName: string) => {
    const normalizedName = cropName.toLowerCase().replace(/\s/g, '');
    const foundImage = PlaceHolderImages.find(img => img.id.includes(normalizedName));
    if (foundImage) return foundImage;
    // Fallback image
    return PlaceHolderImages.find(img => img.id === 'feature-recommendation');
}

const iconMap: { [key: string]: React.ElementType } = { Sprout, Droplets, Shield, Tractor, Thermometer, DollarSign, Wrench };

const DynamicIcon = ({ name }: { name: string }) => {
  const Icon = iconMap[name];
  return Icon ? <Icon className="h-5 w-5 text-primary shrink-0" /> : <Sprout className="h-5 w-5 text-primary shrink-0"/>;
};

const TabContentSkeleton = () => (
  <CardContent className="pt-6 space-y-4">
    <div className="space-y-3">
        <Skeleton className="h-5 w-2/5" />
        <Skeleton className="h-4 w-4/5" />
    </div>
    <div className="space-y-3">
        <Skeleton className="h-5 w-1/3" />
        <Skeleton className="h-4 w-full" />
    </div>
     <div className="space-y-3">
        <Skeleton className="h-5 w-2/5" />
        <Skeleton className="h-4 w-3/5" />
    </div>
  </CardContent>
);

const expenseSchema = z.object({
  expenseType: z.string().min(1, 'Please select an expense type.'),
  amount: z.coerce.number().positive('Amount must be a positive number.'),
  date: z.date(),
  description: z.string().optional(),
});


export function ResultsClient() {
  const searchParams = useSearchParams();
  const { toast } = useToast();
  const { user, loading: userLoading } = useUser();
  const firestore = useFirestore();
  
  const [result, setResult] = useState<RecommendationResult | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectedCropName, setSelectedCropName] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState('care');
  const [tabContent, setTabContent] = useState<CropCareGuidanceOutput | CostEstimationOutput | {error: string} | null>(null);
  const [tabLoading, setTabLoading] = useState(false);
  const [expenses, setExpenses] = useState<any[]>([]);
  const [expensesLoading, setExpensesLoading] = useState(true);

  const location = searchParams.get('location');
  const landArea = searchParams.get('landArea');
  const unit = searchParams.get('unit');
  const season = getSeason();
  
  useEffect(() => {
    if (location && landArea && unit) {
      const fetchRecommendations = async () => {
        setLoading(true);
        const input = {
          location,
          landArea: parseFloat(landArea),
          landAreaUnit: unit as 'acres' | 'hectares',
          season,
        };

        const response = await getRecommendations(input);
        setResult(response);
        if ('error' in response) {
          toast({
            variant: "destructive",
            title: "Error",
            description: response.error,
          });
        } else if(response.suggestedCrops && response.suggestedCrops.length > 0) {
            setSelectedCropName(response.suggestedCrops[0].cropName);
        }
        setLoading(false);
      };

      fetchRecommendations();
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [location, landArea, unit, season]);

  useEffect(() => {
    if (!selectedCropName || !location || !landArea || !unit) return;

    const fetchTabData = async () => {
      setTabLoading(true);
      setTabContent(null);

      try {
        if (activeTab === 'care') {
            const response = await getCropCareAction({ cropName: selectedCropName });
            setTabContent(response);
             if ('error' in response) {
                toast({ variant: "destructive", title: "Could not load crop care data", description: response.error });
            }
        } else if (activeTab === 'cost') {
            const response = await getCostEstimationAction({
                cropName: selectedCropName,
                landArea: parseFloat(landArea),
                landAreaUnit: unit as 'acres' | 'hectares',
                location
            });
            setTabContent(response);
            if ('error' in response) {
                toast({ variant: "destructive", title: "Could not load cost data", description: response.error });
            }
        }
      } catch (e) {
          const errorMsg = 'An unexpected error occurred.';
          toast({ variant: "destructive", title: "Error", description: errorMsg });
          setTabContent({ error: errorMsg });
      } finally {
        setTabLoading(false);
      }
    };

    if (activeTab === 'care' || activeTab === 'cost') {
      fetchTabData();
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedCropName, activeTab, location, landArea, unit]);
  
  useEffect(() => {
    if (user && firestore) {
      setExpensesLoading(true);
      const expensesRef = collection(firestore, 'users', user.uid, 'expenses');
      const q = query(expensesRef, orderBy('date', 'desc'));

      const unsubscribe = onSnapshot(q, (snapshot) => {
        const expensesData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        setExpenses(expensesData);
        setExpensesLoading(false);
      }, (error) => {
        console.error("Error fetching expenses:", error);
        toast({
          variant: "destructive",
          title: "Could not load expenses",
          description: "There was an error fetching your expense data.",
        });
        setExpensesLoading(false);
      });

      return () => unsubscribe();
    } else if (!userLoading) {
      setExpenses([]);
      setExpensesLoading(false);
    }
  }, [user, firestore, userLoading, toast]);


  const expenseForm = useForm<z.infer<typeof expenseSchema>>({
    resolver: zodResolver(expenseSchema),
    defaultValues: {
      amount: undefined,
      date: new Date(),
      description: "",
    },
  });

  async function onExpenseSubmit(values: z.infer<typeof expenseSchema>) {
    if (!user || !firestore) {
        toast({
            variant: "destructive",
            title: "Not logged in",
            description: "You must be logged in to add an expense.",
        });
        return;
    }

    try {
        const expensesRef = collection(firestore, 'users', user.uid, 'expenses');
        await addDoc(expensesRef, {
            ...values,
            userId: user.uid,
            createdAt: Timestamp.now(),
        });

        toast({
            title: "Expense Recorded",
            description: `Logged an expense of $${values.amount.toLocaleString()} for ${values.expenseType}.`,
        });
        expenseForm.reset({ amount: undefined, date: new Date(), description: "", expenseType: undefined });
    } catch (error) {
        console.error("Error adding expense: ", error);
        toast({
            variant: "destructive",
            title: "Error",
            description: "Could not save your expense. Please try again.",
        });
    }
  }


  if (loading) {
    return <Loading />;
  }

  if (!location || !landArea || !unit) {
    return (
      <div className="container py-12 md:py-24 text-center">
        <Alert variant="destructive" className="max-w-md mx-auto">
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>Missing Information</AlertTitle>
          <AlertDescription>
            Location, land area, and unit are required to get recommendations.
          </AlertDescription>
        </Alert>
        <Button asChild className="mt-4">
          <Link href="/advice">Go Back</Link>
        </Button>
      </div>
    );
  }

  if (result && 'error' in result) {
    return (
      <div className="container py-12 md:py-24 text-center">
        <Alert variant="destructive" className="max-w-md mx-auto">
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>An Error Occurred</AlertTitle>
          <AlertDescription>
            {result.error}
          </AlertDescription>
        </Alert>
         <Button asChild className="mt-4">
          <Link href="/advice">Try Again</Link>
        </Button>
      </div>
    );
  }
  
  const crops = result?.suggestedCrops ?? [];
  if (crops.length === 0 && !loading) {
     return (
      <div className="container py-12 md:py-24 text-center">
        <Alert className="max-w-md mx-auto">
          <Sprout className="h-4 w-4" />
          <AlertTitle>No Recommendations Found</AlertTitle>
          <AlertDescription>
            We couldn't find any suitable crop recommendations for the provided details. Please try different inputs.
          </AlertDescription>
        </Alert>
         <Button asChild className="mt-4">
          <Link href="/advice">Try Again</Link>
        </Button>
      </div>
    );
  }

  const careData = (activeTab === 'care' && tabContent && 'guidance' in tabContent) ? tabContent : null;
  const costData = (activeTab === 'cost' && tabContent && 'costBreakdown' in tabContent) ? tabContent : null;

  const ToolsContent = () => {
    if (userLoading) {
        return (
            <CardContent className="flex items-center justify-center p-10">
                <div className="space-y-2">
                    <Skeleton className="h-8 w-48" />
                    <Skeleton className="h-4 w-64" />
                </div>
            </CardContent>
        )
    }
    if (!user) {
        return (
            <CardContent className="flex flex-col items-center justify-center text-center p-10">
                <CardTitle className="font-headline mb-2">Track Your Expenses</CardTitle>
                <p className="text-muted-foreground mb-4">Please log in to manage your farm's finances.</p>
                <Button asChild>
                    <Link href="/login">Login to Get Started</Link>
                </Button>
            </CardContent>
        )
    }

    return (
        <>
              <CardHeader>
                <CardTitle className="font-headline">Finance & Inventory</CardTitle>
                <CardDescription>Log expenses to track your farm's finances. Inventory management coming soon.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-8">
                 <Form {...expenseForm}>
                    <form onSubmit={expenseForm.handleSubmit(onExpenseSubmit)} className="space-y-6">
                        <div className="grid md:grid-cols-2 gap-4">
                            <FormField
                                control={expenseForm.control}
                                name="expenseType"
                                render={({ field }) => (
                                    <FormItem>
                                    <FormLabel>Expense Type</FormLabel>
                                    <Select onValueChange={field.onChange} value={field.value} >
                                        <FormControl>
                                        <SelectTrigger>
                                            <SelectValue placeholder="Select an expense type" />
                                        </SelectTrigger>
                                        </FormControl>
                                        <SelectContent>
                                            <SelectItem value="Seeds">Seeds</SelectItem>
                                            <SelectItem value="Fertilizer">Fertilizer</SelectItem>
                                            <SelectItem value="Pesticides">Pesticides</SelectItem>
                                            <SelectItem value="Labor">Labor</SelectItem>
                                            <SelectItem value="Machinery">Machinery / Fuel</SelectItem>
                                            <SelectItem value="Other">Other</SelectItem>
                                        </SelectContent>
                                    </Select>
                                    <FormMessage />
                                    </FormItem>
                                )}
                            />
                             <FormField
                                control={expenseForm.control}
                                name="amount"
                                render={({ field }) => (
                                    <FormItem>
                                    <FormLabel>Amount ($)</FormLabel>
                                    <FormControl>
                                        <Input type="number" placeholder="150.00" {...field} />
                                    </FormControl>
                                    <FormMessage />
                                    </FormItem>
                                )}
                            />
                        </div>
                        <FormField
                            control={expenseForm.control}
                            name="date"
                            render={({ field }) => (
                                <FormItem className="flex flex-col">
                                <FormLabel>Date of Expense</FormLabel>
                                <Popover>
                                    <PopoverTrigger asChild>
                                    <FormControl>
                                        <Button
                                        variant={"outline"}
                                        className={cn(
                                            "w-[240px] pl-3 text-left font-normal",
                                            !field.value && "text-muted-foreground"
                                        )}
                                        >
                                        {field.value ? (
                                            format(field.value, "PPP")
                                        ) : (
                                            <span>Pick a date</span>
                                        )}
                                        <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                        </Button>
                                    </FormControl>
                                    </PopoverTrigger>
                                    <PopoverContent className="w-auto p-0" align="start">
                                    <CalendarComponent
                                        mode="single"
                                        selected={field.value}
                                        onSelect={field.onChange}
                                        disabled={(date) =>
                                        date > new Date() || date < new Date("1900-01-01")
                                        }
                                        initialFocus
                                    />
                                    </PopoverContent>
                                </Popover>
                                <FormMessage />
                                </FormItem>
                            )}
                        />
                         <FormField
                            control={expenseForm.control}
                            name="description"
                            render={({ field }) => (
                                <FormItem>
                                <FormLabel>Description (Optional)</FormLabel>
                                <FormControl>
                                    <Input placeholder="e.g. Harvest labor for 2 days" {...field} />
                                </FormControl>
                                <FormMessage />
                                </FormItem>
                            )}
                        />
                        <Button type="submit" disabled={expenseForm.formState.isSubmitting}><PlusCircle /> Add Expense</Button>
                    </form>
                 </Form>
                <div className="border-t pt-8">
                    <h3 className="text-lg font-headline mb-4">Recent Expenses</h3>
                    {expensesLoading ? (
                        <div className="space-y-2">
                            <Skeleton className="h-10 w-full" />
                            <Skeleton className="h-10 w-full" />
                            <Skeleton className="h-10 w-full" />
                        </div>
                    ) : expenses.length > 0 ? (
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>Type</TableHead>
                                    <TableHead>Description</TableHead>
                                    <TableHead className="text-right">Amount</TableHead>
                                    <TableHead className="text-right">Date</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {expenses.map(expense => (
                                    <TableRow key={expense.id}>
                                        <TableCell className="font-medium">{expense.expenseType}</TableCell>
                                        <TableCell className="text-muted-foreground">{expense.description || '-'}</TableCell>
                                        <TableCell className="text-right">${expense.amount.toLocaleString()}</TableCell>
                                        <TableCell className="text-right">{expense.date ? format(expense.date.toDate(), 'PP') : 'N/A'}</TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    ) : (
                        <p className="text-muted-foreground text-center py-4">You haven't logged any expenses yet.</p>
                    )}
                </div>
              </CardContent>
        </>
    )
  }

  return (
    <div className="container py-12 md:py-24">
      <div className="max-w-5xl mx-auto">
        <Card className="mb-8 bg-primary/5 border-primary/20">
          <CardHeader>
            <CardTitle className="font-headline text-2xl md:text-3xl text-primary">Your Farm Analysis</CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
            <div className="flex flex-col items-center p-2 rounded-lg">
                <MapPin className="h-8 w-8 text-accent mb-2"/>
                <span className="text-sm text-muted-foreground">Location</span>
                <span className="font-semibold">{location}</span>
            </div>
            <div className="flex flex-col items-center p-2 rounded-lg">
                <Scale className="h-8 w-8 text-accent mb-2"/>
                <span className="text-sm text-muted-foreground">Land Area</span>
                <span className="font-semibold">{landArea} {unit}</span>
            </div>
            <div className="flex flex-col items-center p-2 rounded-lg">
                <Calendar className="h-8 w-8 text-accent mb-2"/>
                <span className="text-sm text-muted-foreground">Season</span>
                <span className="font-semibold">{season}</span>
            </div>
            <div className="flex flex-col items-center p-2 rounded-lg">
                <Sprout className="h-8 w-8 text-accent mb-2"/>
                <span className="text-sm text-muted-foreground">Crops Found</span>
                <span className="font-semibold">{crops.length}</span>
            </div>
          </CardContent>
        </Card>

        <div className="mb-8">
            <h2 className="font-headline text-2xl md:text-3xl font-bold mb-6">Top Recommendations</h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {crops.slice(0, 3).map((crop) => (
                    <Card 
                        key={crop.cropName} 
                        className={cn("flex flex-col overflow-hidden transition-all hover:shadow-xl hover:-translate-y-1 cursor-pointer", selectedCropName === crop.cropName && "ring-2 ring-primary")}
                        onClick={() => setSelectedCropName(crop.cropName)}
                    >
                        <div className="relative h-40 w-full">
                            <Image
                                src={getCropImage(crop.cropName)?.imageUrl ?? ''}
                                alt={crop.cropName}
                                fill
                                className="object-cover"
                                data-ai-hint={getCropImage(crop.cropName)?.imageHint}
                            />
                             <div className="absolute top-2 right-2 bg-primary text-primary-foreground text-xs font-bold py-1 px-2 rounded-full">
                                {crop.suitabilityScore}% Match
                            </div>
                        </div>
                        <CardHeader>
                            <CardTitle className="font-headline">{crop.cropName}</CardTitle>
                        </CardHeader>
                        <CardContent className="flex-grow">
                            <ul className="space-y-2 text-sm">
                                {crop.highlights.map((highlight, i) => (
                                    <li key={i} className="flex items-start gap-2">
                                        <CheckCircle className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                                        <span className="text-muted-foreground">{highlight}</span>
                                    </li>
                                ))}
                            </ul>
                        </CardContent>
                    </Card>
                ))}
            </div>
        </div>

        <Tabs defaultValue="care" className="w-full" onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-3 md:w-auto md:inline-flex">
            <TabsTrigger value="care">Crop Care</TabsTrigger>
            <TabsTrigger value="cost">Cost Estimation</TabsTrigger>
            <TabsTrigger value="tools">Finance</TabsTrigger>
          </TabsList>
          <TabsContent value="care">
            <Card>
              <CardHeader>
                <CardTitle className="font-headline">Crop Care Guidance for {selectedCropName}</CardTitle>
              </CardHeader>
              {tabLoading ? <TabContentSkeleton /> : (
                careData ? (
                  <CardContent className="space-y-4">
                    {careData.guidance.map(step => (
                      <p key={step.title} className="flex items-start gap-3">
                        <DynamicIcon name={step.icon} />
                        <span>
                          <span className="font-semibold">{step.title}:</span> {step.description}
                        </span>
                      </p>
                    ))}
                  </CardContent>
                ) : <CardContent><p className="text-muted-foreground">Could not load crop care guidance.</p></CardContent>
              )}
            </Card>
          </TabsContent>
          <TabsContent value="cost">
            <Card>
              <CardHeader>
                <CardTitle className="font-headline">Cost Estimation for {selectedCropName}</CardTitle>
                <CardDescription>{landArea} {unit}</CardDescription>
              </CardHeader>
               {tabLoading ? <TabContentSkeleton /> : (
                costData ? (
                  <CardContent className="space-y-2">
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6 text-center">
                        <div className="p-4 bg-card rounded-lg">
                            <h4 className="text-sm font-semibold text-muted-foreground">Total Cost</h4>
                            <p className="text-2xl font-bold text-destructive">${costData.totalEstimatedCost.toLocaleString()}</p>
                        </div>
                        <div className="p-4 bg-card rounded-lg">
                            <h4 className="text-sm font-semibold text-muted-foreground">Est. Revenue</h4>
                            <p className="text-2xl font-bold text-primary">${costData.estimatedRevenue.toLocaleString()}</p>
                        </div>
                        <div className="p-4 bg-card rounded-lg col-span-2">
                            <h4 className="text-sm font-semibold text-muted-foreground">Potential Profit</h4>
                            <p className="text-2xl font-bold text-primary">${costData.potentialProfit.toLocaleString()}</p>
                        </div>
                    </div>

                    <h4 className="font-semibold pt-4">Cost Breakdown:</h4>
                    <ul className="space-y-2">
                      {costData.costBreakdown.map(item => (
                        <li key={item.item} className="flex justify-between items-center p-2 rounded-md hover:bg-muted/50">
                          <span className="flex items-center gap-3">
                            <DynamicIcon name={item.icon} />
                            {item.item}
                          </span>
                          <span className="font-semibold">${item.cost.toLocaleString()}</span>
                        </li>
                      ))}
                    </ul>
                    <p className="text-xs text-muted-foreground pt-4">{costData.disclaimer}</p>
                  </CardContent>
                ) : <CardContent><p className="text-muted-foreground">Could not load cost estimation.</p></CardContent>
              )}
            </Card>
          </TabsContent>
          <TabsContent value="tools">
            <Card>
                <ToolsContent />
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
