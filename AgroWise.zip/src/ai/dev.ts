import { config } from 'dotenv';
config();

import '@/ai/flows/optimal-crop-suggestions.ts';
import '@/ai/flows/crop-recommendation-based-on-input-params.ts';
import '@/ai/flows/crop-care-guidance.ts';
import '@/ai/flows/cost-estimation.ts';
