'use server';
/**
 * @fileOverview Generates a cost and profit estimation for a specific crop.
 *
 * - getCostEstimation - A function that provides a breakdown of costs and estimated revenue.
 * - CostEstimationInput - The input type for the function.
 * - CostEstimationOutput - The return type for the function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const CostEstimationInputSchema = z.object({
  cropName: z.string().describe('The name of the crop.'),
  landArea: z.number().describe('The area of the land.'),
  landAreaUnit: z.enum(['acres', 'hectares']).describe('The unit of land area.'),
  location: z.string().describe('The location where the crop is grown, for market price context.')
});
export type CostEstimationInput = z.infer<typeof CostEstimationInputSchema>;

const CostEstimationOutputSchema = z.object({
  costBreakdown: z.array(
    z.object({
      item: z.string().describe('The cost item (e.g., Seeds, Fertilizer, Labor).'),
      cost: z.number().describe('The estimated cost for this item for the total area.'),
      icon: z.enum(['DollarSign', 'Tractor', 'Wrench', 'Sprout', 'Shield']).describe('An appropriate icon name from lucide-react.')
    })
  ).describe('A breakdown of estimated costs for the total land area.'),
  totalEstimatedCost: z.number().describe('The total estimated cost for the entire land area.'),
  estimatedRevenue: z.number().describe('The estimated potential revenue from the harvest.'),
  potentialProfit: z.number().describe('The estimated potential profit.'),
  disclaimer: z.string().describe('A brief disclaimer that these are estimates.')
});
export type CostEstimationOutput = z.infer<typeof CostEstimationOutputSchema>;

export async function getCostEstimation(
  input: CostEstimationInput
): Promise<CostEstimationOutput> {
  return costEstimationFlow(input);
}

const prompt = ai.definePrompt({
  name: 'costEstimationPrompt',
  input: {schema: CostEstimationInputSchema},
  output: {schema: CostEstimationOutputSchema},
  prompt: `You are a farm finance advisor. Create a cost estimation and potential profit analysis for growing {{{cropName}}} on {{{landArea}}} {{{landAreaUnit}}} in {{{location}}}.

Provide a breakdown of major costs. For each cost item, provide an estimated cost for the total land area and suggest an icon from this list: ['DollarSign', 'Tractor', 'Wrench', 'Sprout', 'Shield'].
Calculate the total estimated cost, the potential revenue based on average yield and market prices in the region, and the potential profit.
Finally, add a short disclaimer stating that these are estimates and actual values may vary.

Example cost items:
- Seeds
- Fertilizer
- Pesticides
- Land Preparation
- Labor (sowing, weeding, harvesting)
- Irrigation

Base your estimations on common agricultural practices for the given crop and location. The costs should be for the total land area, not per unit.
`,
});

const costEstimationFlow = ai.defineFlow(
  {
    name: 'costEstimationFlow',
    inputSchema: CostEstimationInputSchema,
    outputSchema: CostEstimationOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
