'use server';

/**
 * @fileOverview Generates crop care guidance.
 *
 * - getCropCareGuidance - A function that provides step-by-step care instructions for a crop.
 * - CropCareGuidanceInput - The input type for the function.
 * - CropCareGuidanceOutput - The return type for the function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const CropCareGuidanceInputSchema = z.object({
  cropName: z.string().describe('The name of the crop.'),
});
export type CropCareGuidanceInput = z.infer<typeof CropCareGuidanceInputSchema>;

const CropCareGuidanceOutputSchema = z.object({
  guidance: z.array(
    z.object({
      title: z.string().describe('The title of the care step (e.g., Land Preparation, Irrigation).'),
      description: z.string().describe('The detailed instructions for this care step.'),
      icon: z.enum(['Sprout', 'Droplets', 'Shield', 'Tractor', 'Thermometer', 'DollarSign', 'Wrench']).describe('An appropriate icon name from lucide-react.')
    })
  ).describe('An array of step-by-step crop care guidance.'),
});
export type CropCareGuidanceOutput = z.infer<typeof CropCareGuidanceOutputSchema>;

export async function getCropCareGuidance(
  input: CropCareGuidanceInput
): Promise<CropCareGuidanceOutput> {
  return cropCareGuidanceFlow(input);
}

const prompt = ai.definePrompt({
  name: 'cropCareGuidancePrompt',
  input: {schema: CropCareGuidanceInputSchema},
  output: {schema: CropCareGuidanceOutputSchema},
  prompt: `You are an agricultural expert. Provide step-by-step crop care guidance for the following crop: {{{cropName}}}.

Provide a list of key care stages. For each stage, provide a title, a short description of the task, and suggest an icon from this list: ['Sprout', 'Droplets', 'Shield', 'Tractor', 'Thermometer', 'DollarSign', 'Wrench'].

Example stages could be:
- Land Preparation
- Sowing/Planting
- Irrigation
- Fertilization
- Pest & Disease Control
- Harvesting

Keep the descriptions concise and practical for a farmer.
`,
});

const cropCareGuidanceFlow = ai.defineFlow(
  {
    name: 'cropCareGuidanceFlow',
    inputSchema: CropCareGuidanceInputSchema,
    outputSchema: CropCareGuidanceOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
