'use server';

/**
 * @fileOverview Provides optimal crop suggestions based on location, season, and land details.
 *
 * - suggestOptimalCrops - A function that suggests optimal crops.
 * - OptimalCropsInput - The input type for the suggestOptimalCrops function.
 * - OptimalCropsOutput - The return type for the suggestOptimalCrops function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const OptimalCropsInputSchema = z.object({
  location: z.string().describe('The geographical location for crop suggestion.'),
  season: z.string().describe('The agricultural season (e.g., Kharif, Rabi, Zaid).'),
  landArea: z.number().describe('The area of land in acres or hectares.'),
  landAreaUnit: z.enum(['acres', 'hectares']).describe('The unit of land area.'),
});
export type OptimalCropsInput = z.infer<typeof OptimalCropsInputSchema>;

const OptimalCropsOutputSchema = z.object({
  suggestedCrops: z.array(
    z.object({
      cropName: z.string().describe('The name of the suggested crop.'),
      suitabilityScore: z.number().describe('A score indicating the suitability of the crop (0-100).'),
      highlights: z.array(z.string()).describe('Key highlights for the suggested crop.'),
    })
  ).describe('An array of suggested crops with their suitability scores and highlights.'),
});
export type OptimalCropsOutput = z.infer<typeof OptimalCropsOutputSchema>;

export async function suggestOptimalCrops(input: OptimalCropsInput): Promise<OptimalCropsOutput> {
  return suggestOptimalCropsFlow(input);
}

const prompt = ai.definePrompt({
  name: 'optimalCropsPrompt',
  input: {schema: OptimalCropsInputSchema},
  output: {schema: OptimalCropsOutputSchema},
  prompt: `You are an expert agricultural advisor. Based on the location, season, and land details provided, suggest the most suitable crops for maximizing yield.

Location: {{{location}}}
Season: {{{season}}}
Land Area: {{{landArea}}} {{{landAreaUnit}}}

Consider the following factors:
- Climate conditions (temperature, rainfall)
- Soil type
- Water availability
- Market demand
- Crop rotation practices

Provide a list of suggested crops with their suitability scores (0-100) and key highlights. Prioritize crops that are well-suited to the given conditions and have high yield potential.

Format the output as a JSON object with a 'suggestedCrops' array. Each crop object should include 'cropName', 'suitabilityScore', and 'highlights'.
`,
});

const suggestOptimalCropsFlow = ai.defineFlow(
  {
    name: 'suggestOptimalCropsFlow',
    inputSchema: OptimalCropsInputSchema,
    outputSchema: OptimalCropsOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
