// src/ai/flows/crop-recommendation-based-on-input-params.ts
'use server';

/**
 * @fileOverview A crop recommendation AI agent based on location and land area.
 *
 * - recommendCrops - A function that handles the crop recommendation process.
 * - RecommendCropsInput - The input type for the recommendCrops function.
 * - RecommendCropsOutput - The return type for the recommendCrops function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const RecommendCropsInputSchema = z.object({
  location: z
    .string()
    .describe('The geographical location where the crops will be planted.'),
  landArea: z
    .number()
    .describe('The area of land available for planting, in acres.'),
});
export type RecommendCropsInput = z.infer<typeof RecommendCropsInputSchema>;

const RecommendCropsOutputSchema = z.object({
  crops: z.array(
    z.object({
      name: z.string().describe('The name of the recommended crop.'),
      suitabilityScore: z
        .number()
        .describe(
          'A score indicating how suitable the crop is for the given location and land area.'
        ),
      highlights: z
        .array(z.string())
        .describe('Key highlights or benefits of growing this crop.'),
    })
  ),
});
export type RecommendCropsOutput = z.infer<typeof RecommendCropsOutputSchema>;

export async function recommendCrops(
  input: RecommendCropsInput
): Promise<RecommendCropsOutput> {
  return recommendCropsFlow(input);
}

const prompt = ai.definePrompt({
  name: 'recommendCropsPrompt',
  input: {schema: RecommendCropsInputSchema},
  output: {schema: RecommendCropsOutputSchema},
  prompt: `You are an expert agricultural advisor. Based on the farmer's location and land area, you will provide a list of the top recommended crops to plant.

Location: {{{location}}}
Land Area: {{{landArea}}} acres

Consider the local climate, soil conditions, and common crops grown in the specified location.
Also, take into account the land area provided to suggest crops that are suitable for that scale of farming.
Your response should be in JSON format.
`,
});

const recommendCropsFlow = ai.defineFlow(
  {
    name: 'recommendCropsFlow',
    inputSchema: RecommendCropsInputSchema,
    outputSchema: RecommendCropsOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
